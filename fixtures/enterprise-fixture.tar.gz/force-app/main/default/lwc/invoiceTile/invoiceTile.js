export default class InvoiceTile {}
